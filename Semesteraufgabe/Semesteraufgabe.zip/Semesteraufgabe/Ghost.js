/*
Aufgabe:    Semesteraufgabe
Name:       Alisia Steiner
Matrikel:   254788
Datum:      21.07.2017

Hiermit versichere ich, dass ich diesen
Code selbst geschrieben habe. Er wurde
nicht kopiert und auch nicht diktiert.
*/
var SpookySpook;
(function (SpookySpook) {
    class Ghost {
        constructor() {
            console.log("New Ghost has suddenly appeared!");
        }
        randomSize() {
        }
        randomPosition() {
        }
        drawGhost() {
        }
        update() {
        }
        move() {
        }
    }
    SpookySpook.Ghost = Ghost;
})(SpookySpook || (SpookySpook = {}));
//# sourceMappingURL=Ghost.js.map