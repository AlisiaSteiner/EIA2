/*
Aufgabe:    Semesteraufgabe
Name:       Alisia Steiner
Matrikel:   254788
Datum:      21.07.2017

Hiermit versichere ich, dass ich diesen
Code selbst geschrieben habe. Er wurde
nicht kopiert und auch nicht diktiert.
*/

namespace SpookySpook {

    export class Ghost {
        
        x: number;
        y: number;
        height: number;
        width: number;
        
        

        constructor() {
            
            console.log("New Ghost has suddenly appeared!");
            
            
            
            }
        
        randomSize(): void {
            
           
            
            }
        
        randomPosition(): void {
            
            
            }
        
        drawGhost(): void {
            
            
            
            
            }
        update(): void {
            
            }
        
        move(): void {
            
            }
        
        
        
        
        
        
        
        
        
        
        }
    }